package com.example.cse441_music.Controller;

import com.example.cse441_music.Model.Song;

public class SongController {
    private Song song;
    // Constructor
    public SongController(Song song) {
        this.song = song;
    }

    public void deleteSong() {
        // Xóa bài hát khỏi dien thoai
    }
}
