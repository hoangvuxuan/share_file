package com.example.cse441_music.Model;

public class Favorite {
}
